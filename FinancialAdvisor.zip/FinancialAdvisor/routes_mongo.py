"""
Flask routes for the MongoDB version of the application
"""
import os
import logging
from datetime import datetime, timedelta
import json
from flask import render_template, redirect, url_for, flash, request, jsonify, session
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from bson import ObjectId
from bson.json_util import dumps

from app_mongo import app, User
from db_mongo import (
    MongoUser, UserPreference, Stock, StockHistory, 
    Portfolio, PortfolioItem, News, Recommendation,
    object_id_to_str
)
from historical_data_fetcher import store_historical_data, get_all_stocks_and_update_history
from data_fetcher import get_stock_data, search_stocks, get_news_data
from sentiment_analysis import analyze_sentiment
from recommendation_mongo import generate_recommendations, calculate_portfolio_performance

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Helper functions
def parse_mongo_obj(obj):
    """Convert MongoDB object to JSON-serializable dict"""
    if isinstance(obj, dict):
        result = {}
        for key, value in obj.items():
            if key == '_id':
                result['id'] = str(value)
            else:
                result[key] = parse_mongo_obj(value)
        return result
    elif isinstance(obj, list):
        return [parse_mongo_obj(item) for item in obj]
    elif isinstance(obj, ObjectId):
        return str(obj)
    else:
        return obj

@app.route('/')
def index():
    """Home page"""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login page"""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user_dict = MongoUser.find_by_username(username)
        
        if user_dict and check_password_hash(user_dict.get('password_hash', ''), password):
            user = User(user_dict)
            login_user(user)
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        
        flash('Invalid username or password', 'danger')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    """Registration page"""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        # Validation
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
            return render_template('register.html')
        
        # Check if username or email already exists
        if MongoUser.find_by_username(username):
            flash('Username already exists', 'danger')
            return render_template('register.html')
        
        if MongoUser.find_by_email(email):
            flash('Email already exists', 'danger')
            return render_template('register.html')
        
        # Create new user
        password_hash = generate_password_hash(password)
        user_id = MongoUser.create(username, email, password_hash)
        
        if user_id:
            # Create default portfolio
            portfolio_id = Portfolio.create(user_id, "My Portfolio", "Default portfolio")
            
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('login'))
        else:
            flash('Registration failed', 'danger')
            return render_template('register.html')
    
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    """Logout user"""
    logout_user()
    flash('You have been logged out', 'success')
    return redirect(url_for('login'))

@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    """User profile page"""
    user_id = current_user.id
    preferences = UserPreference.find_by_user_id(user_id)
    
    if request.method == 'POST':
        # Update profile preferences
        risk_tolerance = request.form.get('risk_tolerance')
        investment_horizon = request.form.get('investment_horizon')
        preferred_sectors = request.form.getlist('sectors')
        preferred_markets = request.form.getlist('markets')
        initial_investment = float(request.form.get('initial_investment', 0))
        
        if preferences:
            # Update existing preferences
            UserPreference.update_one(
                {"user_id": ObjectId(user_id)},
                {
                    "risk_tolerance": risk_tolerance,
                    "investment_horizon": investment_horizon,
                    "preferred_sectors": preferred_sectors,
                    "preferred_markets": preferred_markets,
                    "initial_investment": initial_investment
                }
            )
        else:
            # Create new preferences
            UserPreference.create(
                user_id=ObjectId(user_id),
                risk_tolerance=risk_tolerance,
                investment_horizon=investment_horizon,
                preferred_sectors=preferred_sectors,
                preferred_markets=preferred_markets,
                initial_investment=initial_investment
            )
        
        flash('Profile updated successfully', 'success')
        return redirect(url_for('profile'))
    
    sectors = [
        "Technology", "Healthcare", "Financial Services", "Consumer Goods", 
        "Energy", "Utilities", "Real Estate", "Telecommunications", 
        "Industrial", "Materials"
    ]
    
    markets = [
        "US", "Europe", "Asia", "Emerging Markets", "Global"
    ]
    
    return render_template(
        'profile.html', 
        preferences=preferences,
        sectors=sectors,
        markets=markets
    )

@app.route('/dashboard')
@login_required
def dashboard():
    """User dashboard page"""
    user_id = current_user.id
    
    # Get user portfolio
    portfolios = Portfolio.find_by_user_id(user_id)
    portfolio = portfolios[0] if portfolios else None
    
    portfolio_value = 0
    portfolio_stocks = []
    
    if portfolio:
        # Get portfolio items
        items = PortfolioItem.find_by_portfolio_id(portfolio.get('_id'))
        
        for item in items:
            stock_id = item.get('stock_id')
            stock = Stock.find_by_id(stock_id)
            
            if stock:
                current_price = stock.get('current_price', 0)
                quantity = item.get('quantity', 0)
                purchase_price = item.get('purchase_price', 0)
                
                current_value = current_price * quantity
                portfolio_value += current_value
                
                profit_loss = current_value - (purchase_price * quantity)
                profit_loss_percent = (profit_loss / (purchase_price * quantity)) * 100 if purchase_price > 0 else 0
                
                portfolio_stocks.append({
                    'id': str(stock.get('_id')),
                    'symbol': stock.get('symbol'),
                    'name': stock.get('name'),
                    'current_price': current_price,
                    'quantity': quantity,
                    'purchase_price': purchase_price,
                    'current_value': current_value,
                    'profit_loss': profit_loss,
                    'profit_loss_percent': profit_loss_percent
                })
    
    # Get recommended stocks
    recommended_stocks = []
    recommendations = Recommendation.find_by_user_id(user_id)
    
    for rec in recommendations[:5]:  # Top 5 recommendations
        stock_id = rec.get('stock_id')
        stock = Stock.find_by_id(stock_id)
        
        if stock:
            recommended_stocks.append({
                'id': str(stock.get('_id')),
                'symbol': stock.get('symbol'),
                'name': stock.get('name'),
                'price': stock.get('current_price', 0),
                'score': rec.get('score', 0),
                'reason': rec.get('reason', '')
            })
    
    # Get latest news
    news_items = News.find_recent(limit=4)
    
    return render_template(
        'dashboard.html',
        portfolio_value=portfolio_value,
        portfolio_stocks=sorted(portfolio_stocks, key=lambda x: x['current_value'], reverse=True),
        recommended_stocks=recommended_stocks,
        news_items=news_items
    )

@app.route('/stocks')
@login_required
def stocks():
    """Browse stocks page"""
    # Get all stocks
    all_stocks = Stock.find_all({})
    
    for stock in all_stocks:
        # Convert ObjectId to string for template
        stock['id'] = str(stock.get('_id'))
    
    return render_template('stocks.html', stocks=all_stocks)

@app.route('/stock/<symbol>')
@login_required
def stock_details(symbol):
    """Stock details page"""
    stock = Stock.find_by_symbol(symbol)
    
    if not stock:
        flash(f'Stock {symbol} not found', 'danger')
        return redirect(url_for('stocks'))
    
    stock_id = stock.get('_id')
    
    # Get stock history for chart
    end_date = datetime.now().date()
    start_date = end_date - timedelta(days=90)
    
    history = StockHistory.find_by_stock_id_and_date_range(stock_id, start_date, end_date)
    
    # Prepare chart data
    dates = [h.get('date').strftime('%Y-%m-%d') for h in history]
    prices = [h.get('close_price') for h in history]
    volumes = [h.get('volume') for h in history]
    
    # Get related news
    news_items = News.find_all({"related_symbols": symbol}, sort=[("published_at", -1)], limit=5)
    
    # Check if stock is in user's portfolio
    portfolio = Portfolio.find_by_user_id(current_user.id)[0] if Portfolio.find_by_user_id(current_user.id) else None
    
    in_portfolio = False
    portfolio_item = None
    
    if portfolio:
        portfolio_items = PortfolioItem.find_all({
            "portfolio_id": portfolio.get('_id'),
            "stock_id": stock_id
        })
        
        if portfolio_items:
            in_portfolio = True
            portfolio_item = portfolio_items[0]
    
    # Also get stock data from API for additional details
    stock_data = get_stock_data(symbol)
    
    return render_template(
        'stock_details.html',
        stock=stock,
        stock_data=stock_data,
        dates=dates,
        prices=prices,
        volumes=volumes,
        news_items=news_items,
        in_portfolio=in_portfolio,
        portfolio_item=portfolio_item,
        portfolio_id=str(portfolio.get('_id')) if portfolio else None
    )

@app.route('/portfolio')
@login_required
def portfolio():
    """User portfolio page"""
    user_id = current_user.id
    
    # Get user portfolios
    portfolios = Portfolio.find_by_user_id(user_id)
    
    if not portfolios:
        flash('No portfolio found. Creating one for you.', 'info')
        portfolio_id = Portfolio.create(ObjectId(user_id), "My Portfolio", "Default portfolio")
        portfolios = Portfolio.find_by_user_id(user_id)
    
    portfolio = portfolios[0]  # Use the first portfolio
    portfolio_id = portfolio.get('_id')
    
    # Get portfolio items
    items = PortfolioItem.find_by_portfolio_id(portfolio_id)
    
    portfolio_stocks = []
    total_value = 0
    total_cost = 0
    
    for item in items:
        stock_id = item.get('stock_id')
        stock = Stock.find_by_id(stock_id)
        
        if stock:
            current_price = stock.get('current_price', 0)
            quantity = item.get('quantity', 0)
            purchase_price = item.get('purchase_price', 0)
            
            current_value = current_price * quantity
            cost_basis = purchase_price * quantity
            
            profit_loss = current_value - cost_basis
            profit_loss_percent = (profit_loss / cost_basis) * 100 if cost_basis > 0 else 0
            
            total_value += current_value
            total_cost += cost_basis
            
            portfolio_stocks.append({
                'id': str(item.get('_id')),
                'stock_id': str(stock_id),
                'symbol': stock.get('symbol'),
                'name': stock.get('name'),
                'sector': stock.get('sector'),
                'current_price': current_price,
                'quantity': quantity,
                'purchase_price': purchase_price,
                'current_value': current_value,
                'cost_basis': cost_basis,
                'profit_loss': profit_loss,
                'profit_loss_percent': profit_loss_percent,
                'purchase_date': item.get('purchase_date')
            })
    
    total_profit_loss = total_value - total_cost
    total_profit_loss_percent = (total_profit_loss / total_cost) * 100 if total_cost > 0 else 0
    
    return render_template(
        'portfolio.html',
        portfolio=portfolio,
        portfolio_stocks=portfolio_stocks,
        total_value=total_value,
        total_cost=total_cost,
        total_profit_loss=total_profit_loss,
        total_profit_loss_percent=total_profit_loss_percent
    )

@app.route('/add-to-portfolio', methods=['POST'])
@login_required
def add_to_portfolio():
    """Add stock to portfolio"""
    user_id = current_user.id
    
    if request.method == 'POST':
        symbol = request.form.get('symbol')
        quantity = float(request.form.get('quantity', 0))
        purchase_price = float(request.form.get('purchase_price', 0))
        
        purchase_date_str = request.form.get('purchase_date')
        purchase_date = datetime.strptime(purchase_date_str, '%Y-%m-%d') if purchase_date_str else datetime.utcnow()
        
        # Find the stock
        stock = Stock.find_by_symbol(symbol)
        
        if not stock:
            flash(f'Stock {symbol} not found', 'danger')
            return redirect(url_for('portfolio'))
        
        stock_id = stock.get('_id')
        
        # Find the user's portfolio
        portfolios = Portfolio.find_by_user_id(user_id)
        
        if not portfolios:
            # Create a portfolio if none exists
            portfolio_id = Portfolio.create(ObjectId(user_id), "My Portfolio", "Default portfolio")
            portfolio = Portfolio.find_by_id(portfolio_id)
        else:
            portfolio = portfolios[0]  # Use the first portfolio
        
        portfolio_id = portfolio.get('_id')
        
        # Check if stock already in portfolio
        existing_items = PortfolioItem.find_all({
            "portfolio_id": portfolio_id,
            "stock_id": stock_id
        })
        
        if existing_items:
            # Update existing item
            existing_item = existing_items[0]
            old_quantity = existing_item.get('quantity', 0)
            old_purchase_price = existing_item.get('purchase_price', 0)
            
            # Calculate weighted average purchase price
            total_value = (old_quantity * old_purchase_price) + (quantity * purchase_price)
            new_quantity = old_quantity + quantity
            new_purchase_price = total_value / new_quantity if new_quantity > 0 else 0
            
            PortfolioItem.update_one(
                {"_id": existing_item.get('_id')},
                {
                    "quantity": new_quantity,
                    "purchase_price": new_purchase_price
                }
            )
            
            flash(f'Updated {symbol} in your portfolio', 'success')
        else:
            # Add new item
            PortfolioItem.create(
                portfolio_id=portfolio_id,
                stock_id=stock_id,
                quantity=quantity,
                purchase_price=purchase_price,
                purchase_date=purchase_date
            )
            
            flash(f'Added {symbol} to your portfolio', 'success')
        
        return redirect(url_for('portfolio'))

@app.route('/delete-from-portfolio/<item_id>', methods=['POST'])
@login_required
def delete_from_portfolio(item_id):
    """Delete stock from portfolio"""
    if request.method == 'POST':
        # Convert string ID to ObjectId
        try:
            obj_id = ObjectId(item_id)
        except:
            flash('Invalid item ID', 'danger')
            return redirect(url_for('portfolio'))
        
        # Delete the item
        result = PortfolioItem.delete_one({"_id": obj_id})
        
        if result.deleted_count > 0:
            flash('Item deleted from portfolio', 'success')
        else:
            flash('Item not found', 'danger')
    
    return redirect(url_for('portfolio'))

@app.route('/news')
@login_required
def news():
    """News page"""
    # Get all news items
    all_news = News.find_all({}, sort=[("published_at", -1)])
    
    return render_template('news.html', news_items=all_news)

@app.route('/recommendations')
@login_required
def recommendations():
    """Recommendations page"""
    user_id = current_user.id
    
    # Get user recommendations
    recs = Recommendation.find_by_user_id(user_id)
    
    recommendation_data = []
    
    for rec in recs:
        stock_id = rec.get('stock_id')
        stock = Stock.find_by_id(stock_id)
        
        if stock:
            recommendation_data.append({
                'id': str(rec.get('_id')),
                'stock_id': str(stock_id),
                'symbol': stock.get('symbol'),
                'name': stock.get('name'),
                'sector': stock.get('sector'),
                'price': stock.get('current_price', 0),
                'score': rec.get('score', 0),
                'reason': rec.get('reason', ''),
                'created_at': rec.get('created_at')
            })
    
    return render_template('recommendations.html', recommendations=recommendation_data)

@app.route('/test/generate-recommendations')
@login_required
def test_generate_recommendations():
    """Test route to generate recommendations"""
    try:
        # Check if stocks exist
        stocks_count = Stock.count()
        
        # Add some popular stocks if we don't have enough for good recommendations
        if stocks_count < 10:
            # List of popular stocks to add
            stock_list = [
                {"symbol": "AAPL", "name": "Apple Inc.", "sector": "Technology", "market": "US"},
                {"symbol": "MSFT", "name": "Microsoft Corporation", "sector": "Technology", "market": "US"},
                {"symbol": "AMZN", "name": "Amazon.com Inc.", "sector": "Consumer Goods", "market": "US"},
                {"symbol": "GOOGL", "name": "Alphabet Inc.", "sector": "Technology", "market": "US"},
                {"symbol": "META", "name": "Meta Platforms Inc.", "sector": "Technology", "market": "US"},
                {"symbol": "TSLA", "name": "Tesla Inc.", "sector": "Automotive", "market": "US"},
                {"symbol": "JNJ", "name": "Johnson & Johnson", "sector": "Healthcare", "market": "US"},
                {"symbol": "JPM", "name": "JPMorgan Chase & Co.", "sector": "Financial Services", "market": "US"},
                {"symbol": "V", "name": "Visa Inc.", "sector": "Financial Services", "market": "US"},
                {"symbol": "PG", "name": "Procter & Gamble Co.", "sector": "Consumer Goods", "market": "US"},
                {"symbol": "HD", "name": "Home Depot Inc.", "sector": "Retail", "market": "US"},
                {"symbol": "BAC", "name": "Bank of America Corp.", "sector": "Financial Services", "market": "US"},
                {"symbol": "DIS", "name": "Walt Disney Co.", "sector": "Entertainment", "market": "US"},
                {"symbol": "VZ", "name": "Verizon Communications Inc.", "sector": "Telecommunications", "market": "US"},
                {"symbol": "NFLX", "name": "Netflix Inc.", "sector": "Entertainment", "market": "US"}
            ]
            
            for stock_data in stock_list:
                # Check if stock already exists
                existing = Stock.find_by_symbol(stock_data["symbol"])
                if not existing:
                    # Get current price from API
                    stock_info = get_stock_data(stock_data["symbol"])
                    current_price = stock_info.get('price', 100.0) if stock_info else 100.0
                    
                    # Create the stock
                    Stock.create(
                        symbol=stock_data["symbol"],
                        name=stock_data["name"],
                        sector=stock_data["sector"],
                        market=stock_data["market"],
                        current_price=current_price
                    )
                    
                    # Fetch historical data for the stock
                    store_historical_data(stock_data["symbol"], period="1y")
            
            flash(f'Added stock data for recommendation generation.', 'success')
        
        # Now generate recommendations based on user preferences
        user_id = current_user.id
        success = generate_recommendations(user_id)
        
        if success:
            flash('Recommendations generated successfully!', 'success')
        else:
            flash('Failed to generate recommendations. Please check your preferences.', 'danger')
        
        return redirect(url_for('recommendations'))
        
    except Exception as e:
        logger.error(f"Error generating test recommendations: {e}")
        flash(f'Error: {str(e)}', 'danger')
        return redirect(url_for('recommendations'))

@app.route('/test/generate-news')
def test_generate_news():
    """Test route to generate sample news"""
    try:
        # Check if news already exists
        if News.count() > 0:
            flash('News articles already exist in the database.', 'info')
            return redirect(url_for('news'))
        
        # Get news from API
        news_data = get_news_data()
        
        if not news_data or len(news_data) == 0:
            flash('Failed to fetch news from API', 'danger')
            return redirect(url_for('news'))
        
        # Process and store news
        count = 0
        for article in news_data:
            title = article.get('title', '')
            url = article.get('url', '')
            source = article.get('source', {}).get('name', 'Unknown')
            
            # Parse the published date
            published_at_str = article.get('publishedAt', '')
            try:
                published_at = datetime.strptime(published_at_str, '%Y-%m-%dT%H:%M:%SZ')
            except:
                published_at = datetime.utcnow()
            
            # Generate summary if not present
            summary = article.get('description', '')
            if not summary and article.get('content'):
                summary = article.get('content')[:200] + '...'
            
            # Analyze sentiment if content is available
            sentiment_score = None
            if summary:
                sentiment_score = analyze_sentiment(summary)
            
            # Extract potential stock symbols from title and summary
            combined_text = f"{title} {summary}"
            stock_symbols = []
            
            # Create the news article
            News.create(
                title=title,
                url=url,
                source=source,
                published_at=published_at,
                summary=summary,
                sentiment_score=sentiment_score,
                related_symbols=stock_symbols
            )
            count += 1
        
        flash(f'Generated {count} news articles', 'success')
        return redirect(url_for('news'))
        
    except Exception as e:
        logger.error(f"Error generating news: {e}")
        flash(f'Error: {str(e)}', 'danger')
        return redirect(url_for('news'))

@app.route('/api/stock-price/<symbol>')
def api_stock_price(symbol):
    """API endpoint to get stock price"""
    stock = Stock.find_by_symbol(symbol)
    
    if stock:
        return jsonify({
            'symbol': symbol,
            'price': stock.get('current_price', 0)
        })
    
    # If not in database, try to get from API
    stock_data = get_stock_data(symbol)
    
    if stock_data:
        return jsonify({
            'symbol': symbol,
            'price': stock_data.get('price', 0)
        })
    
    return jsonify({'error': 'Stock not found'}), 404

@app.route('/api/portfolio-performance')
@login_required
def api_portfolio_performance():
    """API endpoint to get portfolio performance data"""
    try:
        user_id = current_user.id
        portfolios = Portfolio.find_by_user_id(user_id)
        
        if not portfolios:
            return jsonify({'error': 'No portfolio found'}), 404
        
        portfolio_id = portfolios[0].get('_id')
        performance_data = calculate_portfolio_performance(portfolio_id)
        
        return jsonify(performance_data)
    except Exception as e:
        logger.error(f"Error getting portfolio performance: {e}")
        return jsonify({'error': 'Failed to get portfolio performance'}), 500

@app.route('/api/historical-data/<symbol>')
def api_historical_data(symbol):
    """API endpoint to get historical stock data"""
    try:
        stock = Stock.find_by_symbol(symbol)
        
        if not stock:
            return jsonify({'error': 'Stock not found'}), 404
        
        stock_id = stock.get('_id')
        
        # Get parameters
        period = request.args.get('period', '1y')
        
        # Calculate date range based on period
        end_date = datetime.now().date()
        
        if period == '1w':
            start_date = end_date - timedelta(days=7)
        elif period == '1m':
            start_date = end_date - timedelta(days=30)
        elif period == '3m':
            start_date = end_date - timedelta(days=90)
        elif period == '6m':
            start_date = end_date - timedelta(days=180)
        elif period == '1y':
            start_date = end_date - timedelta(days=365)
        elif period == '5y':
            start_date = end_date - timedelta(days=365*5)
        else:
            # Default to 1 month
            start_date = end_date - timedelta(days=30)
        
        # Get history
        history = StockHistory.find_by_stock_id_and_date_range(stock_id, start_date, end_date)
        
        # Format data for chart
        data = []
        for h in history:
            data.append({
                'date': h.get('date').strftime('%Y-%m-%d'),
                'open': h.get('open_price'),
                'high': h.get('high_price'),
                'low': h.get('low_price'),
                'close': h.get('close_price'),
                'volume': h.get('volume')
            })
        
        return jsonify({
            'symbol': symbol,
            'data': data
        })
    except Exception as e:
        logger.error(f"Error getting historical data: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/update-history/<symbol>')
@login_required
def update_history(symbol):
    """Update historical data for a stock"""
    try:
        success = store_historical_data(symbol, period="1y")
        
        if success:
            flash(f'Historical data for {symbol} updated successfully', 'success')
        else:
            flash(f'Failed to update historical data for {symbol}', 'danger')
        
        return redirect(url_for('stock_details', symbol=symbol))
    except Exception as e:
        logger.error(f"Error updating historical data: {e}")
        flash(f'Error: {str(e)}', 'danger')
        return redirect(url_for('stock_details', symbol=symbol))

@app.route('/update-all-history')
@login_required
def update_all_history():
    """Update historical data for all stocks"""
    try:
        results = get_all_stocks_and_update_history(period="1y")
        
        success_count = sum(1 for success in results.values() if success)
        total_count = len(results)
        
        if success_count > 0:
            flash(f'Updated historical data for {success_count} of {total_count} stocks', 'success')
        else:
            flash('Failed to update any historical data', 'danger')
        
        return redirect(url_for('dashboard'))
    except Exception as e:
        logger.error(f"Error updating all historical data: {e}")
        flash(f'Error: {str(e)}', 'danger')
        return redirect(url_for('dashboard'))