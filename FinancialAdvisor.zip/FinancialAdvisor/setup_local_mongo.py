"""
Setup script to initialize the MongoDB database with sample data
Run this after setting up your MongoDB database and environment variables
"""

import os
import sys
from datetime import datetime, timedelta
import random
import nltk
import logging
from bson import ObjectId

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Check if .env file exists
if not os.path.exists('.env'):
    print("Error: .env file not found. Please create a .env file with your database configuration.")
    print("Use .env.example as a template.")
    sys.exit(1)

# Make sure required NLTK data is downloaded
try:
    nltk.download('vader_lexicon')
    nltk.download('punkt')
    nltk.download('stopwords')
except Exception as e:
    print(f"Warning: Could not download NLTK data: {e}")

# Import MongoDB models
from db_mongo import (
    create_indexes, 
    MongoUser, UserPreference, Portfolio, Stock, 
    StockHistory, PortfolioItem, News, Recommendation
)
from historical_data_fetcher import store_historical_data
from werkzeug.security import generate_password_hash

def initialize_database():
    """Initialize MongoDB database with indexes"""
    try:
        # Create indexes
        create_indexes()
        print("MongoDB indexes created successfully")
    except Exception as e:
        print(f"Error creating MongoDB indexes: {e}")

def add_sample_data():
    """Add sample data to the MongoDB database"""
    try:
        # Add a sample user if none exists
        if MongoUser.count() == 0:
            print("Adding sample user...")
            user_id = MongoUser.create(
                username="demo_user",
                email="demo@example.com",
                password_hash=generate_password_hash("password123")
            )
            
            # Add user preferences
            UserPreference.create(
                user_id=user_id,
                risk_tolerance="medium",
                investment_horizon="long",
                preferred_sectors=["Technology", "Healthcare", "Financial Services"],
                preferred_markets=["US", "Europe"],
                initial_investment=5000.0
            )
            
            # Create a portfolio
            Portfolio.create(
                user_id=user_id,
                name="My Investment Portfolio",
                description="A sample portfolio for demonstration"
            )
            print("Created user, preferences, and portfolio")

        # Add sample stocks if none exist
        if Stock.count() == 0:
            print("Adding sample stocks...")
            stock_list = [
                {"symbol": "AAPL", "name": "Apple Inc.", "sector": "Technology", "market": "US"},
                {"symbol": "MSFT", "name": "Microsoft Corporation", "sector": "Technology", "market": "US"},
                {"symbol": "AMZN", "name": "Amazon.com Inc.", "sector": "Consumer Goods", "market": "US"},
                {"symbol": "GOOGL", "name": "Alphabet Inc.", "sector": "Technology", "market": "US"},
                {"symbol": "META", "name": "Meta Platforms Inc.", "sector": "Technology", "market": "US"},
                {"symbol": "TSLA", "name": "Tesla Inc.", "sector": "Automotive", "market": "US"},
                {"symbol": "JNJ", "name": "Johnson & Johnson", "sector": "Healthcare", "market": "US"},
                {"symbol": "JPM", "name": "JPMorgan Chase & Co.", "sector": "Financial Services", "market": "US"},
                {"symbol": "V", "name": "Visa Inc.", "sector": "Financial Services", "market": "US"},
                {"symbol": "PG", "name": "Procter & Gamble Co.", "sector": "Consumer Goods", "market": "US"}
            ]
            
            for stock_data in stock_list:
                Stock.create(
                    symbol=stock_data["symbol"],
                    name=stock_data["name"],
                    sector=stock_data["sector"],
                    market=stock_data["market"]
                )
            print("Added 10 sample stocks")

            # Fetch historical data for all stocks
            print("Fetching historical data for stocks (this may take a while)...")
            for stock_data in stock_list:
                print(f"Fetching historical data for {stock_data['symbol']}...")
                store_historical_data(stock_data["symbol"], period="1y")
            print("Finished fetching historical data")

        # Add sample portfolio items if the portfolio is empty
        user = MongoUser.find_by_username("demo_user")
        if user:
            user_id = user.get('_id')
            portfolios = Portfolio.find_by_user_id(user_id)
            
            if portfolios and PortfolioItem.count({"portfolio_id": portfolios[0].get('_id')}) == 0:
                print("Adding sample portfolio items...")
                portfolio_id = portfolios[0].get('_id')
                stocks = Stock.find_all({}, limit=5)
                
                for stock in stocks:
                    stock_id = stock.get('_id')
                    quantity = random.randint(5, 20)
                    
                    # Get current price from historical data
                    latest_history = StockHistory.find_all(
                        {"stock_id": stock_id},
                        sort=[("date", -1)],
                        limit=1
                    )
                    
                    current_price = stock.get('current_price', 100)
                    if latest_history:
                        current_price = latest_history[0].get('close_price')
                    
                    # Calculate a slightly different purchase price
                    purchase_price = current_price * random.uniform(0.9, 1.1)
                    purchase_date = datetime.utcnow() - timedelta(days=random.randint(10, 100))
                    
                    PortfolioItem.create(
                        portfolio_id=portfolio_id,
                        stock_id=stock_id,
                        quantity=quantity,
                        purchase_price=purchase_price,
                        purchase_date=purchase_date
                    )
                print("Added portfolio items")

        # Add sample news if none exists
        if News.count() == 0:
            print("Adding sample news articles...")
            news_list = [
                {
                    "title": "Tech Stocks Rally: AAPL and MSFT Lead Gains",
                    "url": "https://example.com/tech-stocks-rally",
                    "source": "Market News",
                    "published_at": datetime.utcnow() - timedelta(days=1),
                    "summary": "Technology stocks rallied today with Apple and Microsoft leading the gains as investors responded positively to strong earnings reports.",
                    "sentiment_score": 0.65,
                    "related_symbols": ["AAPL", "MSFT"]
                },
                {
                    "title": "Amazon Announces New AI Initiative",
                    "url": "https://example.com/amazon-ai-initiative",
                    "source": "Tech Chronicle",
                    "published_at": datetime.utcnow() - timedelta(days=2),
                    "summary": "Amazon has announced a major investment in artificial intelligence that could transform its e-commerce and cloud services businesses.",
                    "sentiment_score": 0.75,
                    "related_symbols": ["AMZN"]
                },
                {
                    "title": "Federal Reserve Signals Interest Rate Cuts",
                    "url": "https://example.com/fed-rate-cuts",
                    "source": "Financial Times",
                    "published_at": datetime.utcnow() - timedelta(days=3),
                    "summary": "The Federal Reserve has signaled potential interest rate cuts in the coming months as inflation pressures ease.",
                    "sentiment_score": 0.55,
                    "related_symbols": ["JPM", "V"]
                },
                {
                    "title": "Oil Prices Drop on Global Demand Concerns",
                    "url": "https://example.com/oil-prices-drop",
                    "source": "Energy News",
                    "published_at": datetime.utcnow() - timedelta(days=4),
                    "summary": "Oil prices fell sharply today amid growing concerns about global demand and increasing production from major producers.",
                    "sentiment_score": -0.45,
                    "related_symbols": []
                },
                {
                    "title": "Tesla Faces Production Challenges for New Model",
                    "url": "https://example.com/tesla-production-challenges",
                    "source": "Auto Industry Report",
                    "published_at": datetime.utcnow() - timedelta(days=5),
                    "summary": "Tesla is facing production challenges for its newest vehicle model, potentially impacting delivery targets for the quarter.",
                    "sentiment_score": -0.3,
                    "related_symbols": ["TSLA"]
                }
            ]
            
            for news_data in news_list:
                News.create(
                    title=news_data["title"],
                    url=news_data["url"],
                    source=news_data["source"],
                    published_at=news_data["published_at"],
                    summary=news_data["summary"],
                    sentiment_score=news_data["sentiment_score"],
                    related_symbols=news_data["related_symbols"]
                )
            print("Added 5 sample news articles")

        # Generate sample recommendations
        user = MongoUser.find_by_username("demo_user")
        if user:
            user_id = user.get('_id')
            
            if Recommendation.count({"user_id": user_id}) == 0:
                print("Generating sample recommendations...")
                
                # Get user preferences
                user_prefs = UserPreference.find_by_user_id(user_id)
                
                if user_prefs:
                    # Get user's portfolio stocks
                    portfolios = Portfolio.find_by_user_id(user_id)
                    portfolio_stock_ids = []
                    
                    if portfolios:
                        portfolio_id = portfolios[0].get('_id')
                        items = PortfolioItem.find_by_portfolio_id(portfolio_id)
                        portfolio_stock_ids = [item.get('stock_id') for item in items]
                    
                    # Get stocks not in portfolio
                    stocks = Stock.find_all({})
                    for stock in stocks:
                        stock_id = stock.get('_id')
                        
                        if stock_id not in portfolio_stock_ids:
                            # Create a recommendation with a random score
                            score = random.uniform(0.7, 0.95)
                            
                            # Generate a reason based on user preferences
                            sectors = user_prefs.get('preferred_sectors') or []
                            risk_tolerance = user_prefs.get('risk_tolerance') or 'medium'
                            investment_horizon = user_prefs.get('investment_horizon') or 'medium'
                            
                            sector_reason = f", particularly in the {stock.get('sector')} sector" if stock.get('sector') in sectors else ""
                            
                            reason = f"Based on your {risk_tolerance} risk profile{sector_reason}, {stock.get('name')} ({stock.get('symbol')}) shows strong potential for your {investment_horizon}-term investment horizon."
                            
                            Recommendation.create(
                                user_id=user_id,
                                stock_id=stock_id,
                                score=score,
                                reason=reason
                            )
                print("Added sample recommendations")
        
        print("Sample data setup completed successfully!")
    
    except Exception as e:
        print(f"Error adding sample data: {e}")
        raise

if __name__ == "__main__":
    print("Setting up the Financial Investment Recommendation System with MongoDB...")
    initialize_database()
    add_sample_data()
    print("\nSetup complete! You can now run the application with:")
    print("python main_mongo.py")
    print("\nLogin with username: demo_user and password: password123")