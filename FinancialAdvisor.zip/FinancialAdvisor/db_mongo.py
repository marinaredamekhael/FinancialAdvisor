"""
MongoDB database configuration and data models
"""
import os
import logging
import datetime
from pymongo import MongoClient
from pymongo.collection import Collection
from pymongo.database import Database
from bson import ObjectId
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# MongoDB Connection
MONGO_URI = os.environ.get('MONGO_URI', 'mongodb://localhost:27017/')
DB_NAME = os.environ.get('MONGO_DB_NAME', 'investment_db')

# Initialize MongoDB client
client = MongoClient(MONGO_URI)
db = client[DB_NAME]

# Define collections
users = db.users
user_preferences = db.user_preferences
stocks = db.stocks
stock_history = db.stock_history
portfolios = db.portfolios
portfolio_items = db.portfolio_items
news = db.news
recommendations = db.recommendations

# Helper functions
def object_id_to_str(obj):
    """Convert MongoDB ObjectId to string"""
    if isinstance(obj, dict):
        for key, value in obj.items():
            if isinstance(value, ObjectId):
                obj[key] = str(value)
            elif isinstance(value, dict):
                obj[key] = object_id_to_str(value)
            elif isinstance(value, list):
                obj[key] = [object_id_to_str(item) if isinstance(item, dict) else 
                            str(item) if isinstance(item, ObjectId) else item 
                            for item in value]
    return obj

# Model class to provide similar interface to SQLAlchemy
class MongoModel:
    """Base class for MongoDB models to provide SQLAlchemy-like interface"""
    collection = None
    
    @classmethod
    def find_by_id(cls, id):
        """Find document by ID"""
        if isinstance(id, str):
            id = ObjectId(id)
        return cls.collection.find_one({"_id": id})
    
    @classmethod
    def find_one(cls, filter_dict):
        """Find one document matching filter"""
        return cls.collection.find_one(filter_dict)
    
    @classmethod
    def find_all(cls, filter_dict=None, sort=None, limit=None):
        """Find all documents matching filter"""
        if filter_dict is None:
            filter_dict = {}
        
        cursor = cls.collection.find(filter_dict)
        
        if sort:
            cursor = cursor.sort(sort)
        
        if limit:
            cursor = cursor.limit(limit)
            
        return list(cursor)
    
    @classmethod
    def insert_one(cls, document):
        """Insert one document"""
        if '_id' in document and document['_id'] is None:
            document.pop('_id')
        result = cls.collection.insert_one(document)
        return result.inserted_id
    
    @classmethod
    def update_one(cls, filter_dict, update_dict):
        """Update one document"""
        return cls.collection.update_one(filter_dict, {"$set": update_dict})
    
    @classmethod
    def delete_one(cls, filter_dict):
        """Delete one document"""
        return cls.collection.delete_one(filter_dict)
    
    @classmethod
    def count(cls, filter_dict=None):
        """Count documents matching filter"""
        if filter_dict is None:
            filter_dict = {}
        return cls.collection.count_documents(filter_dict)

# Model classes
class User(MongoModel):
    """User model"""
    collection = users
    
    @classmethod
    def create(cls, username, email, password_hash):
        """Create a new user"""
        user_doc = {
            "username": username,
            "email": email,
            "password_hash": password_hash,
            "created_at": datetime.datetime.utcnow()
        }
        user_id = cls.insert_one(user_doc)
        return user_id
    
    @classmethod
    def find_by_username(cls, username):
        """Find user by username"""
        return cls.find_one({"username": username})
    
    @classmethod
    def find_by_email(cls, email):
        """Find user by email"""
        return cls.find_one({"email": email})

class UserPreference(MongoModel):
    """User preference model"""
    collection = user_preferences
    
    @classmethod
    def create(cls, user_id, risk_tolerance, investment_horizon, 
               preferred_sectors=None, preferred_markets=None, initial_investment=0.0):
        """Create user preferences"""
        pref_doc = {
            "user_id": user_id,
            "risk_tolerance": risk_tolerance,
            "investment_horizon": investment_horizon,
            "preferred_sectors": preferred_sectors or [],
            "preferred_markets": preferred_markets or [],
            "initial_investment": initial_investment
        }
        pref_id = cls.insert_one(pref_doc)
        return pref_id
    
    @classmethod
    def find_by_user_id(cls, user_id):
        """Find preferences by user ID"""
        if isinstance(user_id, str) and len(user_id) == 24:
            user_id = ObjectId(user_id)
        return cls.find_one({"user_id": user_id})

class Stock(MongoModel):
    """Stock model"""
    collection = stocks
    
    @classmethod
    def create(cls, symbol, name, sector=None, market=None, current_price=None):
        """Create a new stock"""
        stock_doc = {
            "symbol": symbol,
            "name": name,
            "sector": sector,
            "market": market,
            "current_price": current_price,
            "price_updated_at": datetime.datetime.utcnow() if current_price else None
        }
        stock_id = cls.insert_one(stock_doc)
        return stock_id
    
    @classmethod
    def find_by_symbol(cls, symbol):
        """Find stock by symbol"""
        return cls.find_one({"symbol": symbol})
    
    @classmethod
    def update_price(cls, stock_id, current_price):
        """Update stock price"""
        if isinstance(stock_id, str):
            stock_id = ObjectId(stock_id)
        
        return cls.update_one(
            {"_id": stock_id},
            {
                "current_price": current_price,
                "price_updated_at": datetime.datetime.utcnow()
            }
        )

class StockHistory(MongoModel):
    """Stock history model"""
    collection = stock_history
    
    @classmethod
    def create(cls, stock_id, date, open_price, high_price, low_price, close_price, volume):
        """Create stock history entry"""
        history_doc = {
            "stock_id": stock_id,
            "date": date,
            "open_price": open_price,
            "high_price": high_price,
            "low_price": low_price,
            "close_price": close_price,
            "volume": volume
        }
        history_id = cls.insert_one(history_doc)
        return history_id
    
    @classmethod
    def find_by_stock_id_and_date_range(cls, stock_id, start_date, end_date):
        """Find history by stock ID and date range"""
        if isinstance(stock_id, str):
            stock_id = ObjectId(stock_id)
            
        return cls.find_all(
            {
                "stock_id": stock_id,
                "date": {"$gte": start_date, "$lte": end_date}
            },
            sort=[("date", 1)]  # Sort by date ascending
        )
    
    @classmethod
    def find_latest_by_stock_id(cls, stock_id, limit=30):
        """Find latest history entries by stock ID"""
        if isinstance(stock_id, str):
            stock_id = ObjectId(stock_id)
            
        return cls.find_all(
            {"stock_id": stock_id},
            sort=[("date", -1)],  # Sort by date descending
            limit=limit
        )

class Portfolio(MongoModel):
    """Portfolio model"""
    collection = portfolios
    
    @classmethod
    def create(cls, user_id, name, description=None):
        """Create a new portfolio"""
        portfolio_doc = {
            "user_id": user_id,
            "name": name,
            "description": description,
            "created_at": datetime.datetime.utcnow()
        }
        portfolio_id = cls.insert_one(portfolio_doc)
        return portfolio_id
    
    @classmethod
    def find_by_user_id(cls, user_id):
        """Find portfolios by user ID"""
        if isinstance(user_id, str) and len(user_id) == 24:
            user_id = ObjectId(user_id)
            
        return cls.find_all({"user_id": user_id})

class PortfolioItem(MongoModel):
    """Portfolio item model"""
    collection = portfolio_items
    
    @classmethod
    def create(cls, portfolio_id, stock_id, quantity, purchase_price, purchase_date=None):
        """Create a new portfolio item"""
        item_doc = {
            "portfolio_id": portfolio_id,
            "stock_id": stock_id,
            "quantity": quantity,
            "purchase_price": purchase_price,
            "purchase_date": purchase_date or datetime.datetime.utcnow()
        }
        item_id = cls.insert_one(item_doc)
        return item_id
    
    @classmethod
    def find_by_portfolio_id(cls, portfolio_id):
        """Find items by portfolio ID"""
        if isinstance(portfolio_id, str):
            portfolio_id = ObjectId(portfolio_id)
            
        return cls.find_all({"portfolio_id": portfolio_id})

class News(MongoModel):
    """News model"""
    collection = news
    
    @classmethod
    def create(cls, title, url, source, published_at, summary=None, 
               sentiment_score=None, related_symbols=None):
        """Create a news article"""
        news_doc = {
            "title": title,
            "url": url,
            "source": source,
            "published_at": published_at,
            "summary": summary,
            "sentiment_score": sentiment_score,
            "related_symbols": related_symbols or []
        }
        news_id = cls.insert_one(news_doc)
        return news_id
    
    @classmethod
    def find_recent(cls, limit=10):
        """Find recent news articles"""
        return cls.find_all(
            {}, 
            sort=[("published_at", -1)],  # Sort by published date descending
            limit=limit
        )

class Recommendation(MongoModel):
    """Recommendation model"""
    collection = recommendations
    
    @classmethod
    def create(cls, user_id, stock_id, score, reason=None):
        """Create a recommendation"""
        rec_doc = {
            "user_id": user_id,
            "stock_id": stock_id,
            "score": score,
            "reason": reason,
            "created_at": datetime.datetime.utcnow()
        }
        rec_id = cls.insert_one(rec_doc)
        return rec_id
    
    @classmethod
    def find_by_user_id(cls, user_id):
        """Find recommendations by user ID"""
        if isinstance(user_id, str) and len(user_id) == 24:
            user_id = ObjectId(user_id)
            
        return cls.find_all(
            {"user_id": user_id},
            sort=[("score", -1)]  # Sort by score descending
        )
    
    @classmethod
    def delete_by_user_id(cls, user_id):
        """Delete all recommendations for a user"""
        if isinstance(user_id, str) and len(user_id) == 24:
            user_id = ObjectId(user_id)
            
        return cls.collection.delete_many({"user_id": user_id})

# Create indexes for better query performance
def create_indexes():
    """Create MongoDB indexes"""
    try:
        # User indexes
        users.create_index("username", unique=True)
        users.create_index("email", unique=True)
        
        # Preferences index
        user_preferences.create_index("user_id", unique=True)
        
        # Stock indexes
        stocks.create_index("symbol", unique=True)
        stocks.create_index("sector")
        
        # Stock history indexes
        stock_history.create_index([("stock_id", 1), ("date", 1)], unique=True)
        stock_history.create_index("date")
        
        # Portfolio indexes
        portfolios.create_index("user_id")
        
        # Portfolio item indexes
        portfolio_items.create_index([("portfolio_id", 1), ("stock_id", 1)])
        
        # News indexes
        news.create_index("published_at")
        news.create_index("related_symbols")
        
        # Recommendation indexes
        recommendations.create_index([("user_id", 1), ("stock_id", 1)], unique=True)
        recommendations.create_index([("user_id", 1), ("score", -1)])
        
        logger.info("MongoDB indexes created successfully")
    except Exception as e:
        logger.error(f"Error creating MongoDB indexes: {e}")

# Initialize indexes
create_indexes()